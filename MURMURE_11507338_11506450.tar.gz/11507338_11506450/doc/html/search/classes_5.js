var searchData=
[
  ['hitboxsfml',['HitboxSFML',['../classHitboxSFML.html',1,'']]]
];
