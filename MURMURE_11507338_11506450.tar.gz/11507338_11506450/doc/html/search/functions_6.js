var searchData=
[
  ['hitboxsfml',['HitboxSFML',['../classHitboxSFML.html#aafccc1508ac80fe745810f2d9f4c10b1',1,'HitboxSFML']]]
];
