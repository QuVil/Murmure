#include "SelecPersoSFML.h"

SelecPersoSFML::SelecPersoSFML()
{
    selection = "Green";
}

void SelecPersoSFML::choisir_perso(const Jeu& j)
{

}
